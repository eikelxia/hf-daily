import json, os, base64, math
from datetime import date, datetime, timedelta, timezone
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs

BJT = timezone(timedelta(hours=8))
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "")
REPO_API = "https://api.github.com/repos/eikelxia/hf-daily/contents/data/projects.json"

def http_req(method, url, body=None, headers=None):
    hdrs = {"User-Agent": "hf-daily", "Accept": "application/vnd.github+json"}
    if headers:
        hdrs.update(headers)
    data = body.encode("utf-8") if body else None
    req = Request(url, data=data, headers=hdrs, method=method)
    try:
        resp = urlopen(req, timeout=15)
        return resp.status, resp.read().decode("utf-8")
    except HTTPError as e:
        return e.code, e.read().decode("utf-8")

# ═══════════════════════════════════════════
# 模板引擎（从 daily_scan.py 移植）
# ═══════════════════════════════════════════

HOLIDAYS_2025 = {
    date(2025, 1, 1), date(2025, 1, 28), date(2025, 1, 29), date(2025, 1, 30),
    date(2025, 1, 31), date(2025, 2, 1), date(2025, 2, 2), date(2025, 2, 3),
    date(2025, 2, 4), date(2025, 4, 4), date(2025, 4, 5), date(2025, 4, 6),
    date(2025, 5, 1), date(2025, 5, 2), date(2025, 5, 3), date(2025, 5, 4),
    date(2025, 5, 5), date(2025, 5, 31), date(2025, 6, 1), date(2025, 6, 2),
    date(2025, 10, 1), date(2025, 10, 2), date(2025, 10, 3), date(2025, 10, 4),
    date(2025, 10, 5), date(2025, 10, 6), date(2025, 10, 7), date(2025, 10, 8),
}

def is_workday(d):
    if d.weekday() >= 5: return False
    if d in HOLIDAYS_2025: return False
    return True

def add_workdays(start, days):
    current, count = start, 0
    while count < days:
        current += timedelta(days=1)
        if is_workday(current): count += 1
    return current

def add_natural_days(start, days):
    return start + timedelta(days=days)

def sub_natural_days(end, days):
    return end - timedelta(days=days)

def calc_water_electricity(area):
    if area <= 60: return 1
    elif area <= 100: return 2
    else: return 3

def calc_tile(area):
    return math.ceil(area / 50)

def calc_paint(area):
    if area <= 100: return 5
    else: return math.ceil(area / 100) * 5

def calc_cabinet(area):
    return 7 if area <= 60 else 14

MANUAL_TRIGGER_NODES = {
    "合同签约", "平面图确认", "效果图确认", "施工图确认",
    "空调确认", "消防改造",
}

NODE_TEMPLATES = [
    ("前期资料搜集", "milestone", "startup", lambda a: 2, None, "我", False, False),
    ("催促基础资料提交", "milestone", "startup", lambda a: 1, "前期资料搜集", "我", False, False),
    ("提供门店完全尺寸(CAD)", "milestone", "startup", lambda a: 2, None, "加盟商", False, False),
    ("平面图出图", "milestone", "startup", lambda a: 2, "提供门店完全尺寸(CAD)", "我", False, True),
    ("平面图确认", "milestone", "startup", lambda a: 1, "平面图出图", "加盟商", False, False),
    ("效果图出图", "milestone", "startup", lambda a: 3, "平面图确认", "我", False, True),
    ("效果图确认", "milestone", "startup", lambda a: 1, "效果图出图", "加盟商", False, False),
    ("施工图出图", "milestone", "startup", lambda a: 3, "效果图确认", "我", False, True),
    ("施工图确认", "milestone", "startup", lambda a: 1, "施工图出图", "加盟商", False, False),
    ("合同签约", "milestone", "startup", lambda a: 2, None, "加盟商", False, False),
    ("营业执照办理", "milestone", "startup", lambda a: 7, "合同签约", "加盟商", True, False),
    ("预定柜体", "construction", "construction", calc_cabinet, "施工图确认", "加盟商", False, False),
    ("空调确认", "construction", "construction", lambda a: 2, None, "加盟商", False, False),
    ("办理进场资料", "construction", "construction", lambda a: 1, "施工图确认", "加盟商/施工负责人", False, False),
    ("人员招聘", "milestone", "construction", lambda a: 1, "办理进场资料", "加盟商+小朱", False, False),
    ("砖块隔墙", "construction", "construction", lambda a: 2, "办理进场资料", "加盟商/施工负责人", False, False),
    ("水电改造", "construction", "construction", calc_water_electricity, "砖块隔墙", "加盟商/施工负责人", False, False),
    ("地砖铺贴", "construction", "construction", calc_tile, "水电改造", "加盟商/施工负责人", False, False),
    ("消防改造", "construction", "construction", lambda a: 3, None, "加盟商+二消", False, False),
    ("木工", "construction", "construction", lambda a: 2, "地砖铺贴", "加盟商/施工负责人", False, False),
    ("广告字预订", "construction", "construction", lambda a: 5, "木工", "加盟商/施工负责人", False, False),
    ("漆工", "construction", "construction", calc_paint, "木工", "加盟商/施工负责人", False, False),
    ("柜体安装", "construction", "construction", lambda a: 2, "漆工", "加盟商/施工负责人", False, False),
    ("灯具安装", "construction", "construction", lambda a: 2, "漆工", "加盟商/施工负责人", False, False),
    ("广告字安装", "construction", "construction", lambda a: 1, "漆工", "加盟商/施工负责人", False, False),
    ("美缝保洁", "construction", "construction", lambda a: 1, "柜体安装", "加盟商/施工负责人", False, False),
    ("家具物料进场", "construction", "construction", lambda a: 2, "美缝保洁", "加盟商/施工负责人", False, False),
    ("装修验收", "milestone", "construction", lambda a: 1, "家具物料进场", "加盟商/施工负责人", True, False),
    ("货品货单确认", "countdown", "countdown", lambda a: 14, None, "王雅", False, False),
    ("设计物料确认", "countdown", "countdown", lambda a: 7, None, "陈哇塞", False, False),
    ("开业活动确认", "countdown", "countdown", lambda a: 7, None, "陈哇塞", False, False),
    ("线上培训", "countdown", "countdown", lambda a: 4, None, "小朱", False, False),
    ("培训时间确认", "countdown", "countdown", lambda a: 7, None, "我", False, False),
    ("开业活动物料到场", "countdown", "countdown", lambda a: 3, None, "加盟商", False, False),
    ("美团/抖音/银豹搭建", "countdown", "countdown", lambda a: 3, None, "陈哇塞", False, False),
    ("线下到店培训", "countdown", "countdown", lambda a: 2, None, "我", False, False),
    ("开业验收", "countdown", "countdown", lambda a: 1, None, "我", False, False),
]

def full_schedule(opening_date, store_area, project_start_date=None):
    if project_start_date is None:
        project_start_date = date.today()

    nodes = []
    for i, (name, ntype, stage, duration_fn, depends_on, assignee, is_critical, use_workdays) in enumerate(NODE_TEMPLATES):
        duration = duration_fn(store_area)
        if name in MANUAL_TRIGGER_NODES:
            planned_start, planned_end = None, None
        elif stage == "countdown":
            planned_end = sub_natural_days(opening_date, duration)
            planned_start = planned_end
        else:
            planned_start, planned_end = None, None

        nodes.append({
            "name": name, "node_type": ntype, "stage": stage,
            "planned_start": planned_start.isoformat() if planned_start else None,
            "planned_end": planned_end.isoformat() if planned_end else None,
            "assignee": assignee, "depends_on": depends_on,
            "is_critical": is_critical, "duration": duration,
            "sort_order": i, "status": "pending",
            "actual_start": None, "actual_end": None,
        })

    node_map = {n["name"]: n for n in nodes}

    def parse_date(d):
        if d is None: return None
        if isinstance(d, str): return date.fromisoformat(d)
        return d

    # 启动阶段
    startup_order = [
        "前期资料搜集", "催促基础资料提交", "提供门店完全尺寸(CAD)",
        "平面图出图", "平面图确认", "效果图出图", "效果图确认",
        "施工图出图", "施工图确认",
    ]
    current_date = project_start_date
    for name in startup_order:
        node = node_map.get(name)
        if not node or node.get("stage") != "startup": continue
        if name in MANUAL_TRIGGER_NODES:
            node["planned_start"] = None
            node["planned_end"] = None
            continue
        dep = node.get("depends_on")
        if dep and dep in node_map and node_map[dep].get("planned_end"):
            current_date = parse_date(node_map[dep]["planned_end"])
        duration = node["duration"]
        # 找模板中对应的 use_workdays
        use_wd = False
        for t in NODE_TEMPLATES:
            if t[0] == name:
                use_wd = t[7]
                break
        node["planned_start"] = current_date.isoformat()
        end_date = add_workdays(current_date, duration) if use_wd else add_natural_days(current_date, duration)
        node["planned_end"] = end_date.isoformat()
        current_date = end_date

    # 施工起点
    cons_start_str = node_map.get("施工图确认", {}).get("planned_end") or node_map.get("施工图出图", {}).get("planned_end")
    construction_start = parse_date(cons_start_str) if cons_start_str else project_start_date

    # 装修阶段
    construction_order = [
        "预定柜体", "办理进场资料", "人员招聘", "砖块隔墙",
        "水电改造", "地砖铺贴", "木工", "漆工", "广告字预订",
        "柜体安装", "灯具安装", "广告字安装",
        "美缝保洁", "家具物料进场", "装修验收",
    ]
    current_date = construction_start
    for name in construction_order:
        node = node_map.get(name)
        if not node or node.get("stage") != "construction": continue
        if name in MANUAL_TRIGGER_NODES: continue
        dep = node.get("depends_on")
        if dep and dep in node_map and node_map[dep].get("planned_end"):
            current_date = parse_date(node_map[dep]["planned_end"])
        duration = node["duration"]
        node["planned_start"] = current_date.isoformat()
        node["planned_end"] = add_natural_days(current_date, duration).isoformat()
        current_date = parse_date(node["planned_end"])

    # 漆工和广告字预订并行从木工结束
    wood_end_str = node_map.get("木工", {}).get("planned_end")
    if wood_end_str:
        wood_end = parse_date(wood_end_str)
        for pn in ["漆工", "广告字预订"]:
            n = node_map.get(pn)
            if n and n.get("planned_start") is None:
                n["planned_start"] = wood_end_str
                n["planned_end"] = add_natural_days(wood_end, n["duration"]).isoformat()

    paint_end_str = node_map.get("漆工", {}).get("planned_end")
    if paint_end_str:
        paint_end = parse_date(paint_end_str)
        for pn in ["柜体安装", "灯具安装", "广告字安装"]:
            n = node_map.get(pn)
            if n and n.get("planned_start") is None:
                n["planned_start"] = paint_end_str
                n["planned_end"] = add_natural_days(paint_end, n["duration"]).isoformat()

    cabinet_end_str = node_map.get("柜体安装", {}).get("planned_end")
    if cabinet_end_str:
        cabinet_end = parse_date(cabinet_end_str)
        clean = node_map.get("美缝保洁")
        if clean:
            clean["planned_start"] = cabinet_end_str
            clean["planned_end"] = add_natural_days(cabinet_end, clean["duration"]).isoformat()

    # 移除内部字段
    for n in nodes:
        n.pop("duration", None)

    return nodes


# ═══════════════════════════════════════════
# HTTP Handler
# ═══════════════════════════════════════════

def handler(event, context):
    try:
        if isinstance(event, bytes):
            event = json.loads(event.decode("utf-8"))
        if not isinstance(event, dict):
            return {"statusCode": 200, "body": "ok"}
        if event.get("requestContext", {}).get("http"):
            return handle_http(event)
        return {"statusCode": 200, "body": "ok"}
    except Exception as e:
        return {"statusCode": 200, "headers": {"Content-Type": "text/html; charset=utf-8"},
                "body": "<h1>Error</h1><p>" + str(e) + "</p>"}

def handle_http(event):
    method = (event.get("requestContext", {}).get("http", {}).get("method", "GET") or "GET").upper()
    path = event.get("requestContext", {}).get("http", {}).get("path", "/") or "/"

    if method == "POST" and path == "/create":
        return handle_create(event)
    else:
        return handle_confirm(event)

def handle_create(event):
    """POST /create — 创建新项目"""
    try:
        # 解析 POST body
        body_str = event.get("body", "") or ""
        if event.get("isBase64Encoded"):
            body_str = base64.b64decode(body_str).decode("utf-8")

        # 支持 JSON 和 form-urlencoded
        content_type = ""
        for h in event.get("headers", {}):
            if h.lower() == "content-type":
                content_type = event["headers"][h]
                break

        if "json" in content_type:
            params = json.loads(body_str)
        else:
            params = parse_qs(body_str)
            params = {k: v[0] if isinstance(v, list) and len(v) == 1 else v for k, v in params.items()}

        name = (params.get("name") or "").strip()
        store = (params.get("store") or params.get("store_name") or "").strip()
        opening_date_str = (params.get("opening_date") or params.get("date") or "").strip()
        area_str = (params.get("area") or params.get("store_area") or "0").strip()

        if not name or not opening_date_str:
            return page("缺少参数", "请填写项目名称和开业日期")

        opening_date = date.fromisoformat(opening_date_str)
        area = float(area_str) if area_str else 80.0

        if not GITHUB_TOKEN:
            return page("配置错误", "GITHUB_TOKEN 未设置")

        # 1. 读取现有数据
        hdrs = {"Authorization": "token " + GITHUB_TOKEN}
        status, body = http_req("GET", REPO_API, headers=hdrs)
        if status != 200:
            return page("读取失败", "HTTP " + str(status) + ": " + body[:200])

        fd = json.loads(body)
        sha = fd["sha"]
        data = json.loads(base64.b64decode(fd["content"]).decode("utf-8"))

        # 2. 生成时间线
        nodes = full_schedule(opening_date, area)
        new_id = str(len(data) + 1)

        new_project = {
            "id": new_id,
            "name": name,
            "store_name": store or name,
            "opening_date": opening_date_str,
            "store_area": area,
            "status": "active",
            "created_at": datetime.now(BJT).strftime("%Y-%m-%d"),
            "nodes": nodes,
        }

        data.append(new_project)

        # 3. 写回 GitHub
        new_json = json.dumps(data, ensure_ascii=False, indent=2)
        new_b64 = base64.b64encode(new_json.encode("utf-8")).decode("ascii")
        msg = f"创建项目: {name}"

        put_hdrs = {"Authorization": "token " + GITHUB_TOKEN, "Content-Type": "application/json"}
        put_body = json.dumps({"message": msg, "content": new_b64, "sha": sha})
        status2, body2 = http_req("PUT", REPO_API, body=put_body, headers=put_hdrs)

        if status2 not in [200, 201]:
            return page("保存失败", "HTTP " + str(status2) + ": " + body2[:200])

        # 统计信息
        startup_count = sum(1 for n in nodes if n["stage"] == "startup")
        cons_count = sum(1 for n in nodes if n["stage"] == "construction")
        cd_count = sum(1 for n in nodes if n["stage"] == "countdown")

        result = f"""<b>项目名称:</b> {name}<br>
<b>门店名称:</b> {store or name}<br>
<b>开业日期:</b> {opening_date_str}<br>
<b>门店面积:</b> {area}㎡<br>
<b>总节点数:</b> {len(nodes)} 个<br>
<small>启动阶段 {startup_count} | 装修阶段 {cons_count} | 倒计时 {cd_count}</small><br><br>
<a href="https://eikelxia.github.io/hf-daily/" style="color:#1677ff;font-weight:bold">📋 前往项目看板</a>"""

        return page("项目创建成功", result)

    except Exception as e:
        return page("创建失败", str(e))

def handle_confirm(event):
    """GET / — 确认节点状态"""
    try:
        qp = event.get("queryParameters", {}) or {}
        pid = qp.get("project_id", "")
        nid = qp.get("node_id", "")
        action = qp.get("action", "confirm")
        days = int(qp.get("days", "1"))

        if not pid or not nid:
            return page("缺少参数", "请提供 project_id 和 node_id")
        if not GITHUB_TOKEN:
            return page("配置错误", "GITHUB_TOKEN 未设置")

        anames = {"confirm": "确认开始", "complete": "确认完成", "delay": "延期" + str(days) + "天"}

        # 1. Read file
        hdrs = {"Authorization": "token " + GITHUB_TOKEN}
        status, body = http_req("GET", REPO_API, headers=hdrs)
        if status != 200:
            return page("读取失败", "HTTP " + str(status) + ": " + body[:200])

        fd = json.loads(body)
        sha = fd["sha"]
        data = json.loads(base64.b64decode(fd["content"]).decode("utf-8"))

        # 2. Find and update
        found = False
        pname = nname = assignee = ""
        today = datetime.now(BJT).date()

        for proj in data:
            if str(proj.get("id", "")) == pid:
                pname = proj["name"]
                for node in proj.get("nodes", []):
                    if str(node.get("sort_order", "")) == nid:
                        nname = node["name"]
                        assignee = node.get("assignee", "")
                        found = True

                        if action == "confirm":
                            node["status"] = "in_progress"
                            node["actual_start"] = today.isoformat()
                        elif action == "complete":
                            node["status"] = "completed"
                            node["actual_end"] = today.isoformat()
                        elif action == "delay":
                            node["status"] = "delayed"
                            delta = timedelta(days=days)
                            if node.get("planned_start"):
                                d = date.fromisoformat(node["planned_start"]) + delta
                                node["planned_start"] = d.isoformat()
                            if node.get("planned_end"):
                                d = date.fromisoformat(node["planned_end"]) + delta
                                node["planned_end"] = d.isoformat()
                        break
                break

        if not found:
            return page("未找到", "项目=" + pid + " 节点=" + nid)

        # 3. Write back
        new_json = json.dumps(data, ensure_ascii=False, indent=2)
        new_b64 = base64.b64encode(new_json.encode("utf-8")).decode("ascii")
        msg = anames.get(action, action) + ": " + pname + " - " + nname

        put_hdrs = {"Authorization": "token " + GITHUB_TOKEN, "Content-Type": "application/json"}
        put_body = json.dumps({"message": msg, "content": new_b64, "sha": sha})
        status2, body2 = http_req("PUT", REPO_API, body=put_body, headers=put_hdrs)

        if status2 not in [200, 201]:
            return page("保存失败", "HTTP " + str(status2) + ": " + body2[:200])

        result = "<b>项目:</b> " + pname + "<br>"
        result += "<b>节点:</b> " + nname + "<br>"
        result += "<b>负责人:</b> " + assignee.replace("+", "、") + "<br>"
        result += "<b>操作:</b> " + anames.get(action, action) + "<br>"
        result += "<b>时间:</b> " + datetime.now(BJT).strftime("%Y-%m-%d %H:%M")

        return page("操作成功", result)

    except Exception as e:
        return page("系统错误", str(e))

def page(title, body):
    html = """<!DOCTYPE html>
<html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>""" + title + """</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,sans-serif;background:#f0f2f5;display:flex;justify-content:center;align-items:center;min-height:100vh}
.card{text-align:center;background:#fff;border-radius:12px;padding:40px;width:360px;box-shadow:0 2px 12px rgba(0,0,0,.1)}
h1{font-size:20px;margin-bottom:16px}
p{font-size:14px;color:#666;line-height:1.8}
</style></head>
<body><div class='card'>
<h1>""" + title + """</h1>
<p>""" + body + """</p>
</div></body></html>"""
    return {"statusCode": 200, "headers": {"Content-Type": "text/html; charset=utf-8"}, "body": html}
